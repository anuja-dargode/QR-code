package com.example.attendanceclient;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
Button btnen,btnex;
public static String state;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnen=(Button) findViewById(R.id.btnentry);
        btnex=(Button) findViewById(R.id.btnexit);
        btnen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,ScanActivity.class);
                state="entry";
                startActivity(i);
            }
        });
        btnex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,ScanActivity.class);
                state="exit";
                startActivity(i);
            }
        });
    }
}