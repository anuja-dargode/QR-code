package com.example.attendanceclient;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class SpareActivity extends AppCompatActivity {
TextView tvnote,tt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spare);

        tvnote=(TextView)findViewById(R.id.tvnote);
        tvnote.setText("Marking Attendance");
        String name,id,date,time;
        id=getIntent().getStringExtra("id");
        name=getIntent().getStringExtra("name");


        StringRequest request = new StringRequest(Request.Method.POST, "http://192.168.43.198/EMS-CI/markatten.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getApplicationContext(),"id : "+id+"\nname : "+name+response,Toast.LENGTH_LONG).show();
                        tvnote.setText("Waiting For Next Member");
                        new CountDownTimer(10000, 1000) {

                            public void onTick(long millisUntilFinished) {

                            }

                            public void onFinish() {

                                Intent i =new Intent(SpareActivity.this, ScanActivity.class);
                                startActivity(i);
                            }
                        }.start();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        //  Toast.makeText(MainActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> param = new HashMap<String,String>();
                param.put("id",id);
                param.put("name",name);
                param.put("state",MainActivity.state);


                Log.d("prm",param.toString());

                return param;

            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(request);




    }

    @Override
    public void onBackPressed() {
        Intent i =new Intent(getApplicationContext(),MainActivity.class);
        startActivity(i);
        finishAffinity();
        super.onBackPressed();
    }
}